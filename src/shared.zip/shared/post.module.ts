export class Post
{
    public id:number;
    public title:string;
    public description:string;
    public imagePath:string;
    public quantity:number;
    public comments:string[];

    constructor(id:number,title:string,description:string,
        imagePath:string,quantity:number,comments:string[]=[])
        {
            this.id=id;
            this.title=title;
            this.description=description;
            this.imagePath=imagePath;
            this.quantity=quantity;
            this.comments=[...comments];
        }
}